import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Router} from '@angular/router';
import { resetFakeAsyncZone } from '@angular/core/testing';
@Component({
  selector: 'app-registeration',
  templateUrl: './registeration.component.html',
  styleUrls: ['./registeration.component.css']
})
export class RegisterationComponent implements OnInit {
  
  public username: string = '';
  public password: string = '';
  public result: any = '';
  // public response:any='';
  constructor(private http:HttpClient,private router: Router) { }

  ngOnInit(): void {
    console.log("ywerh")
    // this.r()
    console.log("werter")
  }
  r(){
    const body = { username:this.username ,password:this.password};
    console.log(this.username)
    this.http.post("http://localhost:8080/registeration",body).subscribe(result=> {
     console.log(result)
     
     this.router.navigate(['/login'])

    //  this.response=result
    //  console.log( this.response)
    
})
     
  
  //  console.log(this.result)
}
//  reg(){
//   console.log('First Name: ',this.username);
  
//  }

}
