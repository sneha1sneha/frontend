import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
   result:any=""
   data:any=""
   tokenn:any=""
  constructor(private http:HttpClient) { }

  ngOnInit(): void {
  }
list(){
 
  const local=localStorage.getItem("token")
  console.log(local)
  
  const headers={Authorization:"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MjUsImRpc3BsYXluYW1lIjoiZSIsImlhdCI6MTY3Mjk4MzIwNSwiZXhwIjoxNjczMDEwMjA1fQ.hQ0XiBNnYkgdREV6J2HtTmyTcVl2wIIo5L7PuPN1Jh8"}
  this.http.get("http://localhost:8080/getemp",{headers}).subscribe(result=>{
        // console.log(result)
          this.data=result;
         console.log(this.data)
} )
}
}
