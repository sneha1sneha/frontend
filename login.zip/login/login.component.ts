import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Router} from '@angular/router'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
   public username: string = '';
  public password: string = '';
  public result:string="";
  public data:any="";
    
  constructor(private http:HttpClient,private router: Router) { }

  ngOnInit(): void {
    //  this.loginn()
  }
  // login() {
  //   alert("login clicked")
  //   console.log('First Name: ',this.username);
  //   console.log('Password: ',this.password);
  // }
  loginn(){

    const body = { username:this.username ,password:this.password};
    this.http.post("http://localhost:8080/loginn",body).subscribe((result)=>{
      // console.log(result)
    this.data=result
    console.log(this.data.token)
    if(this.data.token){
      localStorage.setItem('token',JSON.stringify(this.data.token));
   
      // window.location.href="home"
       this.router.navigate(['/home'])
    }
    
    
      
      
        //  window.location.href="home"
       
      
    })
     
  
      
    
   }

 }
